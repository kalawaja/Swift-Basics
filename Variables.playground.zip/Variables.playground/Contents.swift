import UIKit

//String
var firstName="Ramazan"
var lastName="İlter"
print(firstName,lastName)
var userName="kalawaja"
userName.uppercased()
userName.append("1")

//Integer
var internetWebDeveloperNumber=10       //camelCase
var internet_web_developer_number=15    //snake_case
var myNumber=20
var myAnotherNumber=30
myNumber.isMultiple(of: 3)
myAnotherNumber.isMultiple(of: 3)
let myFirstNumber=40
let mySecondNumber=7
myFirstNumber/mySecondNumber

//Double
let pi=3.14
print(pi)
let doubleFirst=40.0
let doubleSecond=7.0
doubleFirst/doubleSecond
var integerSelection:Int16=50
integerSelection=10000000000
let doubleThird:Float=5.23

//Boolean
var electricOn=true
electricOn=false

//Defining
let myStringWord:String
//Initialization
myStringWord="Ramazan"
myStringWord.count


var newGoal:Int
newGoal=20
let newOffside:String
newOffside=String(newGoal)
newOffside+"70"
